Instructions for Compiling:

gcc smallsh.c -o smallsh
